import 'package:flutter/material.dart';

class Result extends StatelessWidget {
  final int resultScore;
  final Function resetHandler;

  Result(this.resultScore, this.resetHandler);

  String get resultPhrase {
    String resultText = 'Quiz End';
    if (resultScore == 100) {
      resultText = 'You get an excellent result';
    } else if (resultScore == 80) {
      resultText = 'You get a good result';
    } else if (resultScore == 60) {
      resultText = 'You get a average result';
    } else if (resultScore == 40) {
      resultText = 'You passed the quiz';
    } else if (resultScore <= 40) {
      resultText = 'Please retake the quiz';
    } else {
      resultText = 'Please do revision again';
    }

    return resultText;
  }

  String get ResultScore {
    String Score = 'Your total score is $resultScore /100';
    return Score;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            resultPhrase,
            style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          Text(
            ResultScore,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          Text(
            'Restart Quiz',
            style: TextStyle(backgroundColor: Colors.tealAccent),
          ),
          TextButton(
            onPressed: resetHandler(),
            child: Container(
              color: Colors.green,
              padding: const EdgeInsets.all(14),
              child: const Text(
                'Restart Quiz',
                style: TextStyle(color: Colors.blue),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
